<script type="text/template" id="fusion-builder-inner-column-template">
	<div class="fusion-builder-controls fusion-builder-column-controls">
		<a href="#" class="fusion-builder-settings fusion-builder-settings-column" title="{{ fusionBuilderText.column_settings }}"><span class="fusiona-pen"></span></a>
	</div>
	<a href="#" class="fusion-builder-add-element" title="{{ fusionBuilderText.add_element }}"><span class="fusiona-plus"></span> {{ fusionBuilderText.element }}</a>
</script>
