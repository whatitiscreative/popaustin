<div class="fusion-upload-file">
	<input id="{{ param.param_name }}" name="{{ param.param_name }}" type="text" class="regular-text fusion-builder-upload-field" value="{{ option_value }}" />
	<input type='button' class='button-upload fusion-builder-upload-button' value='{{ fusionBuilderText.upload }}' data-type="video" data-title="{{ fusionBuilderText.select_video }}"/>
</div>
